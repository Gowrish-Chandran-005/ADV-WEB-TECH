import { useState } from 'react';
import { GearCategory, GearItem, RentalBooking, WantedPost, NotificationItem } from './types';
import {
  INITIAL_ITEMS,
  INITIAL_WANTED,
  INITIAL_NOTIFICATIONS,
  INITIAL_USER_BORROWS,
} from './data/mockData';
import { Header } from './components/Header';
import { LandingView } from './components/LandingView';
import { CampusShelfView } from './components/CampusShelfView';
import { RentModal } from './components/RentModal';
import { ListGearModal } from './components/ListGearModal';
import { CustodyDetailModal } from './components/CustodyDetailModal';
import { WantedReplyModal } from './components/WantedReplyModal';
import { NotificationsModal } from './components/NotificationsModal';
import { HowItWorksModal } from './components/HowItWorksModal';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'campus-shelf'>('landing');
  const [items, setItems] = useState<GearItem[]>(INITIAL_ITEMS);
  const [userBorrows, setUserBorrows] = useState<RentalBooking[]>(INITIAL_USER_BORROWS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [wantedPosts] = useState<WantedPost[]>(INITIAL_WANTED);

  // Filter transfers from Landing to Campus Shelf
  const [shelfCategoryFilter, setShelfCategoryFilter] = useState<GearCategory | undefined>(undefined);
  const [shelfSearchQuery, setShelfSearchQuery] = useState<string>('');

  // Modals state
  const [selectedRentItem, setSelectedRentItem] = useState<GearItem | null>(null);
  const [isListGearOpen, setIsListGearOpen] = useState(false);
  const [isCustodyModalOpen, setIsCustodyModalOpen] = useState(false);
  const [selectedWantedPost, setSelectedWantedPost] = useState<WantedPost | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);

  // Unread notifications count
  const unreadCount = notifications.filter((n) => n.unread).length;

  // Navigation handlers
  const handleGoToShelf = (category?: GearCategory, searchQuery?: string) => {
    setShelfCategoryFilter(category);
    setShelfSearchQuery(searchQuery || '');
    setCurrentView('campus-shelf');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleBookmark = (itemId: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, isBookmarked: !item.isBookmarked } : item
      )
    );
  };

  const handleAddItem = (newItem: GearItem) => {
    setItems((prev) => [newItem, ...prev]);
    // Also add notification
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}`,
        title: `Gear Listed: ${newItem.title}`,
        message: 'Your item is live on the campus shelf with automated escrow protection.',
        timeAgo: 'Just now',
        unread: true,
        type: 'booking',
      },
      ...prev,
    ]);
  };

  const handleConfirmRent = (
    item: GearItem,
    days: number,
    startDate: string,
    endDate: string
  ) => {
    const newBooking: RentalBooking = {
      id: `booking-${Date.now()}`,
      item,
      startDate,
      endDate,
      totalDays: days,
      rentalFee: item.pricePerDay * days,
      depositAmount: item.depositAmount,
      status: 'active',
      custodyStampId: `VERIFIED CUSTODY #${Math.floor(800 + Math.random() * 200)}`,
      timestamp: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      pickupPhotosVerified: true,
      returnPhotosVerified: false,
    };

    setUserBorrows((prev) => [newBooking, ...prev]);

    // Add notification
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}`,
        title: `Booking Confirmed · ${item.title}`,
        message: `Escrow hold ₹${item.depositAmount} locked. Handover scheduled at ${item.owner.handoverLocation}.`,
        timeAgo: 'Just now',
        unread: true,
        type: 'booking',
      },
      ...prev,
    ]);

    setSelectedRentItem(null);
    setCurrentView('campus-shelf');
  };

  const handleWantedReply = (wantedId: string) => {
    const post = wantedPosts.find((p) => p.id === wantedId) || wantedPosts[0];
    setSelectedWantedPost(post);
  };

  const handleSubmitWantedReply = (postId: string, replyText: string) => {
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}`,
        title: 'Reply Sent on Bulletin',
        message: `You offered gear to Aarav: "${replyText.slice(0, 50)}..."`,
        timeAgo: 'Just now',
        unread: true,
        type: 'reply',
      },
      ...prev,
    ]);
  };

  const handleMarkAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  return (
    <div className="min-h-screen bg-[#fdf9f1] text-[#1c1c17] flex flex-col font-body selection:bg-[#b2eee7] selection:text-[#094d48]">
      {/* Top Navigation Bar */}
      <Header
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenListGear={() => setIsListGearOpen(true)}
        onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadCount={unreadCount}
      />

      {/* Main View Router */}
      <main className="w-full pt-20 flex-1 flex flex-col">
        {currentView === 'landing' ? (
          <LandingView
            items={items}
            onGoToShelf={handleGoToShelf}
            onOpenListGear={() => setIsListGearOpen(true)}
            onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
            onRentItem={(item) => setSelectedRentItem(item)}
            onToggleBookmark={handleToggleBookmark}
            onOpenCustodyModal={() => setIsCustodyModalOpen(true)}
            onOpenWantedReply={handleWantedReply}
          />
        ) : (
          <CampusShelfView
            items={items}
            userBorrows={userBorrows}
            initialCategory={shelfCategoryFilter}
            initialSearch={shelfSearchQuery}
            onOpenListGear={() => setIsListGearOpen(true)}
            onRentItem={(item) => setSelectedRentItem(item)}
            onToggleBookmark={handleToggleBookmark}
            onOpenCustodyModal={() => setIsCustodyModalOpen(true)}
            onBackToNoticeboard={() => setCurrentView('landing')}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
          />
        )}
      </main>

      {/* MODALS */}
      <RentModal
        item={selectedRentItem}
        onClose={() => setSelectedRentItem(null)}
        onConfirmRent={handleConfirmRent}
      />

      <ListGearModal
        isOpen={isListGearOpen}
        onClose={() => setIsListGearOpen(false)}
        onAddItem={handleAddItem}
      />

      <CustodyDetailModal
        isOpen={isCustodyModalOpen}
        onClose={() => setIsCustodyModalOpen(false)}
      />

      <WantedReplyModal
        post={selectedWantedPost}
        onClose={() => setSelectedWantedPost(null)}
        onSubmitReply={handleSubmitWantedReply}
      />

      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllRead}
      />

      <HowItWorksModal
        isOpen={isHowItWorksOpen}
        onClose={() => setIsHowItWorksOpen(false)}
        onOpenListGear={() => setIsListGearOpen(true)}
      />
    </div>
  );
}
