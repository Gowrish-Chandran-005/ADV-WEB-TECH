export type GearCategory = 
  | 'Cameras' 
  | 'Drones' 
  | 'Audio & Mics' 
  | 'Projectors' 
  | 'Outdoors' 
  | 'Makers & Tools';

export interface GearItem {
  id: string;
  title: string;
  category: GearCategory;
  location: string;
  rating: number;
  reviewsCount: number;
  pricePerDay: number;
  depositAmount: number;
  description: string;
  badge?: 'Just Listed' | 'Available Now' | 'Near Media Lab' | 'Weekend Special' | 'Popular';
  badgeColor?: string;
  imageUrl: string;
  owner: {
    name: string;
    avatarInitials: string;
    rating: number;
    department: string;
    handoverLocation: string;
  };
  pickupCheckImage?: string;
  returnCheckImage?: string;
  isBookmarked?: boolean;
}

export interface RentalBooking {
  id: string;
  item: GearItem;
  startDate: string;
  endDate: string;
  totalDays: number;
  rentalFee: number;
  depositAmount: number;
  status: 'active' | 'pending_pickup' | 'returned' | 'deposit_released';
  custodyStampId: string;
  timestamp: string;
  pickupPhotosVerified: boolean;
  returnPhotosVerified: boolean;
}

export interface WantedPost {
  id: string;
  author: string;
  location: string;
  text: string;
  repliesCount: number;
  timeAgo: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timeAgo: string;
  unread: boolean;
  type: 'deposit' | 'booking' | 'reply';
}
