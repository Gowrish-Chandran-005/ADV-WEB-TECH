import React from 'react';

interface HeaderProps {
  currentView: 'landing' | 'campus-shelf';
  onNavigate: (view: 'landing' | 'campus-shelf') => void;
  onOpenListGear: () => void;
  onOpenHowItWorks: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenListGear,
  onOpenHowItWorks,
  onOpenNotifications,
  unreadCount,
}) => {
  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#fdf9f1]/90 backdrop-blur-md border-b border-[#bfc8c6]">
      <div className="h-20 max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Brand Logo & Stamp */}
        <div className="flex items-center gap-6">
          <button 
            onClick={() => onNavigate('landing')}
            className="flex items-center gap-2 group text-left cursor-pointer"
          >
            <img 
              alt="GearLoop Logo" 
              className="h-8 w-auto object-contain" 
              src="https://lh3.googleusercontent.com/aida/AEtjO1Xl_zDYCfQvvkF4_399sn-3GdR1ETq9jcSYe3GJDdauNDCD6AfQM85qCJWQen7lUj66qBzvM3ElpAALIlgpi1DaLja2Z1rO6e0L2h8D5Q6Juhk61WF2Tt7CoJ5kLO_sm9PU66SMW7tv7TAoO_y_5QWUiSc5x76s-v75yXBlJuy9GEGjRFk9mAQs26C0KyEzI0ik-J5kTs_AFIiBV9eSK35Cvo_hRhxiNXdD_9J2r43FVICwnIt7mlGec3LD"
            />
            <span className="font-headline-sm text-2xl text-[#094d48] tracking-tight font-bold">
              GearLoop
            </span>
          </button>
          
          <div className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full border border-dashed border-[#bfc8c6] bg-[#f7f3eb] text-[#404947] font-label-stamp text-[11px] uppercase -rotate-1 select-none">
            Campus verified
          </div>
        </div>

        {/* Center Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => onNavigate('landing')}
            className={`transition-colors text-sm font-medium ${
              currentView === 'landing'
                ? 'text-[#094d48] font-bold underline underline-offset-8 decoration-[#994531]'
                : 'text-[#404947] hover:text-[#1c1c17]'
            }`}
          >
            Noticeboard
          </button>

          <button
            onClick={() => onNavigate('campus-shelf')}
            className={`transition-colors text-sm font-medium ${
              currentView === 'campus-shelf'
                ? 'text-[#094d48] font-bold underline underline-offset-8 decoration-[#994531]'
                : 'text-[#404947] hover:text-[#1c1c17]'
            }`}
          >
            The Campus Shelf
          </button>

          <button
            onClick={onOpenHowItWorks}
            className="text-sm font-medium text-[#404947] hover:text-[#1c1c17] transition-colors"
          >
            How it works
          </button>

          <button
            onClick={onOpenListGear}
            className="text-sm font-medium text-[#404947] hover:text-[#1c1c17] transition-colors flex items-center gap-1"
          >
            <span className="font-mono text-xs">+</span> List your gear
          </button>
        </nav>

        {/* Right CTA & Profile */}
        <div className="flex items-center gap-3">
          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-full text-[#404947] hover:text-[#1c1c17] hover:bg-[#ece8e0] transition-colors"
            title="Campus Notifications"
          >
            <span className="material-symbols-outlined text-[22px]">notifications</span>
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#994531] ring-2 ring-[#fdf9f1]" />
            )}
          </button>

          {/* Quick Toggle view button */}
          <button
            onClick={() => onNavigate(currentView === 'landing' ? 'campus-shelf' : 'landing')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#bfc8c6] text-xs font-mono font-medium hover:border-[#094d48] text-[#404947] hover:text-[#094d48] transition-all bg-[#ffffff]/60"
          >
            <span className="material-symbols-outlined text-sm">
              {currentView === 'landing' ? 'dashboard' : 'campaign'}
            </span>
            <span>{currentView === 'landing' ? 'App Shelf' : 'Noticeboard'}</span>
          </button>

          {/* Sign Up / List CTA button */}
          <button
            onClick={onOpenListGear}
            className="inline-flex items-center justify-center bg-[#094d48] text-white font-label-btn text-sm px-4 py-2 rounded-full shadow-[0_4px_0_0_#0e4f4b] hover:translate-y-0.5 hover:shadow-[0_2px_0_0_#0e4f4b] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
          >
            <span>List Gear</span>
            <span className="ml-1.5 font-mono">→</span>
          </button>

          {/* User Profile Avatar */}
          <button
            onClick={() => onNavigate('campus-shelf')}
            className="relative p-0.5 rounded-full ring-2 ring-[#bfc8c6]/60 hover:ring-[#094d48] transition-all ml-1 cursor-pointer"
            title="Your Profile & Dashboard"
          >
            <img 
              alt="Profile" 
              className="w-8 h-8 rounded-full object-cover" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuA9l-X8GdjLL0rcPL7hcCEgt9nphjHzQJCPS-_74XNQgBZmc_yz-0y5KscAOM8JeWO1i3KLYAWP0NzjZ48l1wsvNgTuCNRBveCSytyTEZvg7dJvS8MCB5-scic6hKveP0MB05Pbp8XRvjE0_W1wI6DXBcyQbAAQX3gfp_VT2YdiarKildqwCgLAR49hC6qGszyvlta5Sp770J4uFS9N21mr09NrFpOjvtVnRvGGIyjw8x5R-VERMK4yTA"
            />
          </button>
        </div>
      </div>
    </header>
  );
};
