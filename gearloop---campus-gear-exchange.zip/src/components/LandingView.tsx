import React, { useState } from 'react';
import { GearCategory, GearItem } from '../types';

interface LandingViewProps {
  items: GearItem[];
  onGoToShelf: (category?: GearCategory, searchQuery?: string) => void;
  onOpenListGear: () => void;
  onOpenHowItWorks: () => void;
  onRentItem: (item: GearItem) => void;
  onToggleBookmark: (itemId: string) => void;
  onOpenCustodyModal: () => void;
  onOpenWantedReply: (wantedId: string) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  items,
  onGoToShelf,
  onOpenListGear,
  onOpenHowItWorks,
  onRentItem,
  onToggleBookmark,
  onOpenCustodyModal,
  onOpenWantedReply,
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [locationInput, setLocationInput] = useState('Vellore (Campus & Town)');
  const [timeInput, setTimeInput] = useState('This Weekend');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onGoToShelf(undefined, searchInput.trim());
  };

  const freshListings = items.slice(0, 4);

  return (
    <div className="flex flex-col w-full overflow-hidden">
      {/* HERO SECTION */}
      <section className="max-w-7xl mx-auto px-6 py-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Copy & Identity */}
          <div className="lg:col-span-6 flex flex-col items-start gap-4">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#ece8e0]">
              <span className="w-2 h-2 rounded-full bg-[#094d48] animate-pulse"></span>
              <span className="font-label-eyebrow text-xs text-[#094d48] uppercase tracking-wider font-semibold">
                The gear shelf, open
              </span>
            </div>

            {/* Giant Headline */}
            <h1 className="font-headline-xl text-4xl sm:text-5xl lg:text-[54px] text-[#1c1c17] tracking-tight leading-[1.08] font-bold">
              Borrow the gear. <br />
              <span className="text-[#994531] inline-block relative">
                Keep it moving.
                <svg
                  className="absolute -bottom-2 left-0 w-full h-3 text-[#fd947b]"
                  fill="none"
                  preserveAspectRatio="none"
                  viewBox="0 0 200 12"
                >
                  <path
                    d="M2 9.5C50 3.5 140 2 198 8"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeWidth="4"
                  />
                </svg>
              </span>
            </h1>

            {/* Subtitle */}
            <p className="font-body-lg text-lg text-[#404947] max-w-lg mt-1 leading-relaxed">
              GearLoop is the friendly campus collective to rent what you need and lend what you're not using. Clear condition logs, trusted peers, zero deposit awkwardness.
            </p>

            {/* CTA Row */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => onGoToShelf()}
                className="inline-flex items-center justify-center bg-[#094d48] text-white font-label-btn text-base px-6 py-3.5 rounded-full shadow-[0_4px_0_0_#0e4f4b] hover:translate-y-0.5 hover:shadow-[0_2px_0_0_#0e4f4b] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
              >
                Find gear <span className="ml-2 font-mono">→</span>
              </button>

              <button
                onClick={onOpenListGear}
                className="inline-flex items-center font-label-btn text-base text-[#094d48] hover:text-[#2a6560] px-4 py-2.5 rounded-full transition-colors group cursor-pointer font-bold"
              >
                <span className="font-label-stamp text-xs mr-2 group-hover:scale-125 transition-transform font-bold">
                  +
                </span>
                I have gear to lend
              </button>
            </div>

            {/* Social Proof Avatars */}
            <div className="flex items-center gap-4 pt-2">
              <div className="flex -space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#fd947b] text-[#762b1a] font-headline-sm text-xs font-bold flex items-center justify-center shadow-sm ring-2 ring-[#fdf9f1]">
                  MK
                </div>
                <div className="w-10 h-10 rounded-full bg-[#dae2ff] text-[#111b33] font-headline-sm text-xs font-bold flex items-center justify-center shadow-sm ring-2 ring-[#fdf9f1]">
                  AR
                </div>
                <div className="w-10 h-10 rounded-full bg-[#b2eee7] text-[#00201e] font-headline-sm text-xs font-bold flex items-center justify-center shadow-sm ring-2 ring-[#fdf9f1]">
                  PS
                </div>
                <div className="w-10 h-10 rounded-full bg-[#e6e2da] text-[#404947] font-label-stamp text-xs flex items-center justify-center shadow-sm ring-2 ring-[#fdf9f1] font-bold">
                  +84
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-body-sm text-sm font-semibold text-[#1c1c17]">
                  Made for campus makers
                </span>
                <span className="font-label-stamp text-xs text-[#404947]">
                  320+ verified handovers this month
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Noticeboard Cork/Teal Panel */}
          <div className="lg:col-span-6 relative">
            {/* Floating decorative star doodle */}
            <div className="absolute -top-4 -right-2 text-[#994531] z-20 pointer-events-none select-none animate-pulse">
              <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 40 40">
                <path
                  d="M20 0L23 14L37 17L25 25L28 39L18 29L7 37L12 23L0 17L14 13L20 0Z"
                  opacity="0.85"
                />
              </svg>
            </div>

            {/* Main Teal Board Frame */}
            <div className="relative bg-[#094d48] text-white rounded-[28px] p-6 md:p-8 shadow-2xl overflow-hidden min-h-[460px] flex flex-col justify-between border-4 border-[#073c38]">
              {/* Dot grid pattern overlay */}
              <div
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#b2eee7 1.5px, transparent 1.5px)',
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Board Header Tag */}
              <div className="relative z-10 flex items-center justify-between pb-4">
                <span className="font-label-stamp text-xs text-[#b2eee7] uppercase tracking-wider font-bold">
                  GEARLOOP / NOTICEBOARD 01
                </span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#2a6560] text-[#a5e0d9] font-label-stamp text-[10px] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#b2eee7] animate-ping" />
                  VELLORE PINBOARD
                </span>
              </div>

              {/* Staggered Pinned Cards Container */}
              <div className="relative z-10 w-full my-auto py-2">
                {/* Card 1: Equipment Listing Note (tilted -3deg) */}
                <div
                  onClick={() => onRentItem(items[0])}
                  className="relative bg-white text-[#1c1c17] rounded-2xl p-4 shadow-xl transform -rotate-3 hover:rotate-0 hover:scale-[1.02] transition-all duration-300 max-w-sm ml-2 cursor-pointer border border-[#ece8e0]"
                >
                  {/* Pin Dot at Top Center */}
                  <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-[#994531] shadow-md flex items-center justify-center ring-2 ring-white">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#fdf9f1]" />
                  </div>

                  {/* Content Header */}
                  <div className="flex items-center justify-between text-[#404947] pt-2">
                    <span className="font-label-stamp text-[11px] text-[#994531] uppercase font-bold">
                      JUST POSTED · 2h ago
                    </span>
                    <span className="font-label-stamp text-[11px] bg-[#ece8e0] px-2 py-0.5 rounded font-bold">
                      ID: #4092
                    </span>
                  </div>

                  {/* Icon & Title */}
                  <div className="flex items-center gap-3 mt-3">
                    <div className="w-14 h-14 rounded-2xl bg-[#ffdad2] flex items-center justify-center shrink-0">
                      <span className="material-symbols-outlined text-[#994531] text-3xl">
                        photo_camera
                      </span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <h2 className="font-headline-sm text-lg text-[#1c1c17] truncate font-bold">
                        Sony Alpha A7 IV
                      </h2>
                      <p className="font-body-sm text-xs text-[#404947] truncate">
                        Body + 28-70mm OSS lens
                      </p>
                    </div>
                  </div>

                  {/* Owner and Price */}
                  <div className="flex items-center justify-between mt-4 pt-2 bg-[#f7f3eb] rounded-xl p-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-[#094d48] text-white flex items-center justify-center text-xs font-bold font-mono">
                        MK
                      </div>
                      <span className="font-body-sm text-xs text-[#1c1c17] font-semibold">
                        Meera K.
                      </span>
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded font-label-stamp text-[9px] bg-[#b2eee7] text-[#00201e] font-bold">
                        ★ 4.98
                      </span>
                    </div>
                    <div className="font-headline-sm text-base text-[#094d48] font-bold">
                      ₹1,200
                      <span className="font-body-sm text-xs text-[#404947] font-normal">
                        /day
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card 2: Wanted Request Note (tilted +4deg, overlapping) */}
                <div className="relative bg-[#e6e2da] text-[#1c1c17] rounded-2xl p-4 shadow-2xl transform rotate-4 hover:rotate-0 hover:scale-[1.02] transition-all duration-300 max-w-xs -mt-10 ml-auto mr-2 border border-[#bfc8c6]">
                  {/* Tape header strip */}
                  <div className="absolute -top-3 left-1/3 w-16 h-6 bg-[#fdf9f1]/80 backdrop-blur-sm -rotate-6 rounded-sm shadow-sm pointer-events-none" />

                  <div className="flex items-center justify-between pb-1">
                    <span className="font-label-stamp text-[10px] bg-[#fd947b] text-[#762b1a] px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                      WANTED
                    </span>
                    <span className="material-symbols-outlined text-[#707977] text-base">
                      push_pin
                    </span>
                  </div>

                  <p className="font-headline-sm text-sm text-[#1c1c17] font-semibold italic mt-1 leading-snug">
                    "Does anyone have a gimbal for a Saturday dance film shoot?"
                  </p>

                  <div className="mt-3 flex items-center justify-between text-[#404947]">
                    <span className="font-label-eyebrow text-[11px]">
                      — Aarav, 3rd Floor Studio
                    </span>
                    <button
                      onClick={() => onOpenWantedReply('w-1')}
                      className="font-label-stamp text-xs text-[#094d48] font-bold underline hover:text-[#2a6560] cursor-pointer"
                    >
                      Reply
                    </button>
                  </div>
                </div>
              </div>

              {/* Bottom micro footer inside panel */}
              <div className="relative z-10 flex items-center justify-between pt-2 text-[#97d1cb] border-t border-[#2a6560]/60">
                <span className="font-label-stamp text-[11px] font-medium">
                  VIT CAMPUS · T-HUB BLOCK
                </span>
                <span className="font-label-stamp text-[11px] font-bold">
                  UPDATED REAL-TIME
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SEARCH BAR BAND (Segmented Campus Slip) */}
      <section className="max-w-7xl mx-auto px-6 w-full -mt-2 mb-10">
        <form
          onSubmit={handleHeroSearch}
          className="bg-white rounded-3xl p-3 md:p-4 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-[#ece8e0]"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2 items-center">
            {/* What */}
            <div className="lg:col-span-4 p-2 rounded-2xl hover:bg-[#f7f3eb] transition-colors flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#f1ede6] flex items-center justify-center text-[#094d48] shrink-0">
                <span className="material-symbols-outlined text-xl">search</span>
              </div>
              <div className="flex flex-col min-w-0 w-full">
                <label className="font-label-eyebrow text-[11px] text-[#404947] uppercase font-bold">
                  What gear?
                </label>
                <input
                  type="text"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder="DSLR, drone, mic, projector..."
                  className="w-full bg-transparent font-body-md text-sm text-[#1c1c17] placeholder:text-[#707977] focus:outline-none truncate"
                />
              </div>
            </div>

            {/* Where */}
            <div className="lg:col-span-3 p-2 rounded-2xl hover:bg-[#f7f3eb] transition-colors flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#f1ede6] flex items-center justify-center text-[#994531] shrink-0">
                <span className="material-symbols-outlined text-xl">location_on</span>
              </div>
              <div className="flex flex-col min-w-0 w-full">
                <label className="font-label-eyebrow text-[11px] text-[#404947] uppercase font-bold">
                  Where
                </label>
                <input
                  type="text"
                  value={locationInput}
                  onChange={(e) => setLocationInput(e.target.value)}
                  className="w-full bg-transparent font-body-md text-sm text-[#1c1c17] placeholder:text-[#707977] focus:outline-none truncate"
                />
              </div>
            </div>

            {/* When */}
            <div className="lg:col-span-3 p-2 rounded-2xl hover:bg-[#f7f3eb] transition-colors flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#f1ede6] flex items-center justify-center text-[#3b445e] shrink-0">
                <span className="material-symbols-outlined text-xl">calendar_month</span>
              </div>
              <div className="flex flex-col min-w-0 w-full">
                <label className="font-label-eyebrow text-[11px] text-[#404947] uppercase font-bold">
                  When
                </label>
                <input
                  type="text"
                  value={timeInput}
                  onChange={(e) => setTimeInput(e.target.value)}
                  className="w-full bg-transparent font-body-md text-sm text-[#1c1c17] placeholder:text-[#707977] focus:outline-none truncate"
                />
              </div>
            </div>

            {/* Action CTA */}
            <div className="lg:col-span-2 p-1 flex justify-end">
              <button
                type="submit"
                className="w-full lg:w-auto inline-flex items-center justify-center gap-2 bg-[#094d48] text-white font-label-btn text-sm px-6 py-3.5 rounded-2xl shadow-[0_4px_0_0_#0e4f4b] hover:translate-y-0.5 hover:shadow-[0_2px_0_0_#0e4f4b] active:translate-y-1 active:shadow-none transition-all cursor-pointer font-bold"
              >
                <span>Search</span>
                <span className="font-mono">→</span>
              </button>
            </div>
          </div>
        </form>
      </section>

      {/* CATEGORY CHIPS STRIP */}
      <section className="max-w-7xl mx-auto px-6 w-full mb-12">
        <div className="flex items-center justify-between mb-3">
          <span className="font-label-eyebrow text-xs text-[#404947] uppercase font-bold tracking-wider">
            Pinned Gear Categories
          </span>
          <button
            onClick={() => onGoToShelf()}
            className="font-label-stamp text-xs text-[#094d48] underline font-bold cursor-pointer hover:text-[#2a6560]"
          >
            Browse All (210)
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Chip 1: Cameras */}
          <button
            onClick={() => onGoToShelf('Cameras')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#ffdad2] flex items-center justify-center text-[#994531] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">photo_camera</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Cameras
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">48 active</p>
            </div>
          </button>

          {/* Chip 2: Drones */}
          <button
            onClick={() => onGoToShelf('Drones')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#b2eee7] flex items-center justify-center text-[#094d48] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">flight_takeoff</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Drones
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">19 active</p>
            </div>
          </button>

          {/* Chip 3: Audio & Mics */}
          <button
            onClick={() => onGoToShelf('Audio & Mics')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#dae2ff] flex items-center justify-center text-[#3b445e] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">mic</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Audio & Mics
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">34 active</p>
            </div>
          </button>

          {/* Chip 4: Projectors */}
          <button
            onClick={() => onGoToShelf('Projectors')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#ffdad2] flex items-center justify-center text-[#994531] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">videocam</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Projectors
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">14 active</p>
            </div>
          </button>

          {/* Chip 5: Outdoors */}
          <button
            onClick={() => onGoToShelf('Outdoors')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#b2eee7] flex items-center justify-center text-[#094d48] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">cabin</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Outdoors
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">27 active</p>
            </div>
          </button>

          {/* Chip 6: Makers & Tools */}
          <button
            onClick={() => onGoToShelf('Makers & Tools')}
            className="group bg-white p-3 rounded-2xl flex items-center gap-3 hover:shadow-md transition-all text-left border border-[#ece8e0] cursor-pointer hover:border-[#094d48]"
          >
            <div className="w-10 h-10 rounded-xl bg-[#dae2ff] flex items-center justify-center text-[#3b445e] group-hover:scale-110 transition-transform shrink-0">
              <span className="material-symbols-outlined text-xl">build</span>
            </div>
            <div className="min-w-0">
              <p className="font-body-sm text-sm font-bold text-[#1c1c17] group-hover:text-[#094d48] truncate">
                Makers & Tools
              </p>
              <p className="font-label-stamp text-[10px] text-[#404947]">62 active</p>
            </div>
          </button>
        </div>
      </section>

      {/* HOW IT WORKS: THE FOUR-STEP LOOP */}
      <section className="bg-[#f7f3eb] py-14 w-full my-6 border-y border-[#ece8e0]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col items-center text-center max-w-xl mx-auto mb-12">
            <span className="font-label-eyebrow text-xs text-[#094d48] uppercase font-bold tracking-wider">
              The Four-Step Loop
            </span>
            <h2 className="font-headline-lg text-3xl md:text-4xl text-[#1c1c17] mt-1 font-bold">
              Borrow with zero awkwardness.
            </h2>
            <p className="font-body-md text-base text-[#404947] mt-2">
              Designed for high-trust peer rentals. Every deposit is held secure, and every handover is cataloged.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
            {/* Step 1 */}
            <div className="bg-white p-6 rounded-3xl flex flex-col justify-between shadow-sm relative group hover:-translate-y-1 transition-transform border border-[#ece8e0]">
              <div className="flex items-center justify-between">
                <span className="font-label-stamp text-xs text-[#2a6560] bg-[#ece8e0] px-2 py-0.5 rounded font-bold">
                  STEP 01
                </span>
                <span className="w-3 h-3 rounded-full bg-[#fd947b]" />
              </div>
              <div className="my-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-[#ffdad2] flex items-center justify-center mb-3 text-[#994531]">
                  <span className="material-symbols-outlined text-3xl">travel_explore</span>
                </div>
                <h3 className="font-headline-sm text-lg text-[#1c1c17] font-bold">
                  List or find
                </h3>
                <p className="font-body-sm text-xs text-[#404947] mt-1.5 leading-relaxed">
                  Pin your idle kit or pick verified gear from creators nearby on your campus board.
                </p>
              </div>
              <div className="font-label-stamp text-[10px] text-[#404947] text-center uppercase tracking-wider font-bold">
                Free to browse
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-white p-6 rounded-3xl flex flex-col justify-between shadow-sm relative group hover:-translate-y-1 transition-transform border border-[#ece8e0]">
              <div className="flex items-center justify-between">
                <span className="font-label-stamp text-xs text-[#2a6560] bg-[#ece8e0] px-2 py-0.5 rounded font-bold">
                  STEP 02
                </span>
                <span className="w-3 h-3 rounded-full bg-[#b2eee7]" />
              </div>
              <div className="my-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-[#e6e2da] flex items-center justify-center mb-3 text-[#094d48]">
                  <span className="material-symbols-outlined text-3xl">security</span>
                </div>
                <h3 className="font-headline-sm text-lg text-[#1c1c17] font-bold">
                  Book & escrow deposit
                </h3>
                <p className="font-body-sm text-xs text-[#404947] mt-1.5 leading-relaxed">
                  Lock in your rental dates. Refundable deposits are held safely in trust until return.
                </p>
              </div>
              <div className="font-label-stamp text-[10px] text-[#404947] text-center uppercase tracking-wider font-bold">
                Automated escrow
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white p-6 rounded-3xl flex flex-col justify-between shadow-sm relative group hover:-translate-y-1 transition-transform border border-[#ece8e0]">
              <div className="flex items-center justify-between">
                <span className="font-label-stamp text-xs text-[#2a6560] bg-[#ece8e0] px-2 py-0.5 rounded font-bold">
                  STEP 03
                </span>
                <span className="w-3 h-3 rounded-full bg-[#dae2ff]" />
              </div>
              <div className="my-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-[#b2eee7] flex items-center justify-center mb-3 text-[#094d48]">
                  <span className="material-symbols-outlined text-3xl">checklist_rtl</span>
                </div>
                <h3 className="font-headline-sm text-lg text-[#1c1c17] font-bold">
                  Handover with proof
                </h3>
                <p className="font-body-sm text-xs text-[#404947] mt-1.5 leading-relaxed">
                  Snap 3 quick photos on your phone. Both parties sign the digital timestamped custody log.
                </p>
              </div>
              <div className="font-label-stamp text-[10px] text-[#404947] text-center uppercase tracking-wider font-bold">
                Zero disputes
              </div>
            </div>

            {/* Step 4 */}
            <div className="bg-white p-6 rounded-3xl flex flex-col justify-between shadow-sm relative group hover:-translate-y-1 transition-transform border border-[#ece8e0]">
              <div className="flex items-center justify-between">
                <span className="font-label-stamp text-xs text-[#2a6560] bg-[#ece8e0] px-2 py-0.5 rounded font-bold">
                  STEP 04
                </span>
                <span className="w-3 h-3 rounded-full bg-[#ffdad2]" />
              </div>
              <div className="my-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-[#ffdad2] flex items-center justify-center mb-3 text-[#994531]">
                  <span className="material-symbols-outlined text-3xl">handshake</span>
                </div>
                <h3 className="font-headline-sm text-lg text-[#1c1c17] font-bold">
                  Return & review
                </h3>
                <p className="font-body-sm text-xs text-[#404947] mt-1.5 leading-relaxed">
                  Drop gear back, unlock your deposit instantly, and pin peer praise to their profile.
                </p>
              </div>
              <div className="font-label-stamp text-[10px] text-[#404947] text-center uppercase tracking-wider font-bold">
                Instant release
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURE SPOTLIGHT: RENT WITH PROOF */}
      <section className="max-w-7xl mx-auto px-6 py-10 w-full">
        <div className="bg-[#f1ede6] rounded-[32px] p-6 md:p-10 overflow-hidden border border-[#e6e2da]">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Text details */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              <div className="inline-flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#994531]" />
                <span className="font-label-stamp text-xs text-[#994531] uppercase font-bold tracking-wider">
                  THE RENT WITH PROOF™ GUARANTEE
                </span>
              </div>
              <h2 className="font-headline-lg text-3xl md:text-4xl text-[#1c1c17] font-bold leading-tight">
                Timestamped custody stamps. <br />
                No deposit panic.
              </h2>
              <p className="font-body-md text-base text-[#404947] leading-relaxed">
                Lending expensive cameras or synthesizers to people on campus used to feel risky. GearLoop fixes this with our physical check protocol: photograph glass condition, record serial numbers, and lock custody in 90 seconds.
              </p>

              <div className="space-y-3 pt-1">
                <div className="flex items-start gap-3">
                  <span className="material-symbols-outlined text-[#094d48] text-xl mt-0.5">
                    verified
                  </span>
                  <div>
                    <h4 className="font-headline-sm text-sm text-[#1c1c17] font-bold">
                      Side-by-side condition matching
                    </h4>
                    <p className="font-body-sm text-xs text-[#404947]">
                      Pickup vs return photos compared transparently with micro-detail zoom.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="material-symbols-outlined text-[#094d48] text-xl mt-0.5">
                    lock_clock
                  </span>
                  <div>
                    <h4 className="font-headline-sm text-sm text-[#1c1c17] font-bold">
                      Protected Escrow Release
                    </h4>
                    <p className="font-body-sm text-xs text-[#404947]">
                      Security deposit is returned automatically once both peers confirm inspection.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenCustodyModal}
                  className="inline-flex items-center font-label-btn text-sm text-[#094d48] font-bold hover:underline cursor-pointer"
                >
                  Read the Custody Protocol Handbook <span className="ml-1 font-mono">→</span>
                </button>
              </div>
            </div>

            {/* Visual Proof Mockup Card */}
            <div className="lg:col-span-6">
              <div 
                onClick={onOpenCustodyModal}
                className="bg-white rounded-3xl p-4 md:p-6 shadow-xl relative cursor-pointer hover:shadow-2xl transition-all border border-[#ece8e0]"
              >
                {/* Stamp Badge */}
                <div className="absolute -top-3 -right-3 z-20 px-3 py-1 bg-white text-[#094d48] rounded-lg border-2 border-dashed border-[#094d48] rotate-12 shadow-sm font-label-stamp text-xs font-bold">
                  VERIFIED CUSTODY #882
                </div>

                <div className="flex items-center justify-between pb-3 border-b border-[#ece8e0]">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#094d48]">
                      security_update_good
                    </span>
                    <span className="font-headline-sm text-sm font-bold text-[#1c1c17]">
                      Inspection Log · Canon RF 24-70mm
                    </span>
                  </div>
                  <span className="font-label-stamp text-xs text-[#404947]">
                    OCT 14, 14:22
                  </span>
                </div>

                {/* Two Comparison Photos (Pickup vs Return) */}
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="flex flex-col gap-1">
                    <span className="font-label-stamp text-[10px] text-[#404947] uppercase font-bold">
                      Pickup Check (Lender)
                    </span>
                    <div className="h-44 rounded-2xl overflow-hidden bg-[#ece8e0] relative group">
                      <img
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        alt="Pickup lens inspection check"
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuBcphJvV4lvjCzbX5yD1NkvXZjDaqbDCiPW80BSaU6JBG_EEuvCW9tNAf7y2HI8utklTlJKnCbN1TlKpsCYqTO2eXl8qQV10fkm7uk2yeeZbuuX7X2oJeWRgAist_NMGKDEr6NXFtDHUXwXJLSD61HRCEoZtEOhWLOO3WsinEdCtIgWwL-kVw4HRm_K0H7LlBjKnvAuKy8nUXIfK98PqrRNk__8-zv73_HvGoZ1oJEjl-dRam_54M1dAQ"
                      />
                      <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-white/95 font-label-stamp text-[9px] text-[#094d48] font-bold shadow-xs">
                        LENS FRONT: CLEAN
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="font-label-stamp text-[10px] text-[#404947] uppercase font-bold">
                      Return Check (Renter)
                    </span>
                    <div className="h-44 rounded-2xl overflow-hidden bg-[#ece8e0] relative group">
                      <img
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        alt="Return lens optic inspection check"
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuB5PF6yslGXk97XRF8RPOp0O-w0yc_WpUYLaZHE9p_AT9Rf2QrKv5V-IXp9bk_4HUEVbQ8-LsxHgX4ih2bIMwZE8SQS3pC3eVnnWNYBJGFbjSixPaC_1OF336yWpEb8XhFBXdpsG3kf5cOlcLrySiKXYyzhmjSb1TaMz7u7rBrmdK1psPEJtB88jM3sJfyHHWnuf0bNx3LK_mjmOGFb4x37JI3NEdRiwJ4sFB9om9i4Vv8-uPWa4J-vJg"
                      />
                      <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-white/95 font-label-stamp text-[9px] text-[#094d48] font-bold shadow-xs">
                        REAR CONTACTS: OK
                      </div>
                    </div>
                  </div>
                </div>

                {/* Checklist status pills */}
                <div className="grid grid-cols-3 gap-2 mt-4 pt-1">
                  <div className="p-2 rounded-xl bg-[#f7f3eb] flex items-center gap-1.5 border border-[#e6e2da]">
                    <span className="material-symbols-outlined text-[#094d48] text-base">
                      check_circle
                    </span>
                    <span className="font-label-stamp text-[10px] text-[#1c1c17] font-bold">
                      Outer Body
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-[#f7f3eb] flex items-center gap-1.5 border border-[#e6e2da]">
                    <span className="material-symbols-outlined text-[#094d48] text-base">
                      check_circle
                    </span>
                    <span className="font-label-stamp text-[10px] text-[#1c1c17] font-bold">
                      Front Glass
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-[#f7f3eb] flex items-center gap-1.5 border border-[#e6e2da]">
                    <span className="material-symbols-outlined text-[#094d48] text-base">
                      check_circle
                    </span>
                    <span className="font-label-stamp text-[10px] text-[#1c1c17] font-bold">
                      Focus Ring
                    </span>
                  </div>
                </div>

                {/* Signed info banner */}
                <div className="mt-4 p-2.5 rounded-xl bg-[#b2eee7]/40 flex items-center justify-between text-[#00201e] border border-[#97d1cb]">
                  <span className="font-body-sm text-xs font-semibold">
                    Both Meera K. & Rishi V. approved condition
                  </span>
                  <span className="font-label-stamp text-[10px] uppercase font-bold bg-[#094d48] text-white px-2 py-0.5 rounded">
                    Deposit Released
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FRESH ON THE SHELF (Listings Grid) */}
      <section className="max-w-7xl mx-auto px-6 py-10 w-full">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-3">
          <div>
            <div className="inline-flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#994531] animate-ping" />
              <span className="font-label-eyebrow text-xs text-[#994531] uppercase font-bold tracking-wider">
                Fresh Listings
              </span>
            </div>
            <h2 className="font-headline-lg text-3xl md:text-4xl text-[#1c1c17] mt-1 font-bold">
              Fresh on the shelf this week
            </h2>
          </div>
          <button
            onClick={() => onGoToShelf()}
            className="font-label-btn text-sm text-[#094d48] hover:underline flex items-center gap-1 font-bold cursor-pointer"
          >
            View all 210 listings <span className="font-mono">→</span>
          </button>
        </div>

        {/* 4-Card Gear Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {freshListings.map((gear) => (
            <div
              key={gear.id}
              className="bg-white rounded-3xl p-3 flex flex-col shadow-sm hover:shadow-xl transition-all duration-300 group border border-[#ece8e0]"
            >
              {/* Image banner */}
              <div className="relative h-56 rounded-2xl overflow-hidden bg-[#ece8e0]">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  alt={gear.title}
                  src={gear.imageUrl}
                />
                {gear.badge && (
                  <div
                    className={`absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full font-label-stamp text-[10px] uppercase font-bold ${
                      gear.badge === 'Just Listed'
                        ? 'bg-[#994531] text-white'
                        : gear.badge === 'Available Now'
                        ? 'bg-[#b2eee7] text-[#00201e]'
                        : gear.badge === 'Weekend Special'
                        ? 'bg-[#ffdad2] text-[#3d0600]'
                        : 'bg-[#f1ede6] text-[#404947]'
                    }`}
                  >
                    {gear.badge}
                  </div>
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleBookmark(gear.id);
                  }}
                  className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/80 backdrop-blur-md flex items-center justify-center transition-colors cursor-pointer ${
                    gear.isBookmarked
                      ? 'text-[#994531]'
                      : 'text-[#1c1c17] hover:text-[#994531]'
                  }`}
                  title={gear.isBookmarked ? 'Remove bookmark' : 'Bookmark gear'}
                >
                  <span className="material-symbols-outlined text-lg">
                    {gear.isBookmarked ? 'bookmark_added' : 'bookmark'}
                  </span>
                </button>
              </div>

              {/* Card Meta */}
              <div className="p-3 flex flex-col justify-between flex-grow">
                <div>
                  <div className="flex items-center justify-between text-[#404947]">
                    <span className="font-label-stamp text-[10px] uppercase font-bold truncate max-w-[150px]">
                      {gear.category.toUpperCase()} · {gear.location.toUpperCase()}
                    </span>
                    <span className="font-label-stamp text-[11px] text-[#094d48] font-bold">
                      ★ {gear.rating}
                    </span>
                  </div>
                  <h3 className="font-headline-sm text-base font-bold text-[#1c1c17] mt-1 group-hover:text-[#094d48] transition-colors line-clamp-1">
                    {gear.title}
                  </h3>
                  <p className="font-body-sm text-xs text-[#404947] mt-1 line-clamp-1">
                    {gear.description}
                  </p>
                </div>

                <div className="flex items-center justify-between mt-4 pt-2 border-t border-[#ece8e0]">
                  <div className="font-headline-sm text-base text-[#094d48] font-bold">
                    ₹{gear.pricePerDay.toLocaleString()}
                    <span className="font-body-sm text-xs text-[#404947] font-normal">
                      /day
                    </span>
                  </div>
                  <button
                    onClick={() => onRentItem(gear)}
                    className="px-3.5 py-1.5 rounded-full bg-[#f1ede6] hover:bg-[#094d48] hover:text-white font-label-btn text-xs font-bold text-[#1c1c17] transition-colors cursor-pointer"
                  >
                    Rent
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CAMPUS TESTIMONIALS (Tactile Pinned Post-its) */}
      <section className="max-w-7xl mx-auto px-6 py-10 w-full">
        <div className="text-center max-w-lg mx-auto mb-10">
          <span className="font-label-eyebrow text-xs text-[#094d48] uppercase font-bold tracking-wider">
            Pinned From The Bulletin
          </span>
          <h2 className="font-headline-lg text-3xl text-[#1c1c17] mt-1 font-bold">
            What the makers are saying.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Note 1 */}
          <div className="relative bg-white rounded-3xl p-6 shadow-md transform -rotate-2 hover:rotate-0 transition-transform border border-[#ece8e0]">
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#994531] shadow" />
            <p className="font-body-lg text-base text-[#1c1c17] italic leading-relaxed pt-2">
              "Saved ₹14,000 renting a cinema prime lens for our final semester graduation film. Handover took 3 minutes at the food street."
            </p>
            <div className="flex items-center gap-3 mt-6 pt-2 border-t border-[#ece8e0]">
              <div className="w-8 h-8 rounded-full bg-[#ffdad2] text-[#994531] flex items-center justify-center font-bold text-xs">
                RM
              </div>
              <div>
                <h4 className="font-headline-sm text-xs font-bold text-[#1c1c17]">
                  Rohan M.
                </h4>
                <p className="font-label-stamp text-[10px] text-[#404947]">
                  Film Society President
                </p>
              </div>
            </div>
          </div>

          {/* Note 2 */}
          <div className="relative bg-white rounded-3xl p-6 shadow-md transform rotate-2 hover:rotate-0 transition-transform border border-[#ece8e0]">
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#094d48] shadow" />
            <p className="font-body-lg text-base text-[#1c1c17] italic leading-relaxed pt-2">
              "My backup camera paid for my entire semester design textbook bill while I was buried in exam revision week. Win-win."
            </p>
            <div className="flex items-center gap-3 mt-6 pt-2 border-t border-[#ece8e0]">
              <div className="w-8 h-8 rounded-full bg-[#b2eee7] text-[#094d48] flex items-center justify-center font-bold text-xs">
                PS
              </div>
              <div>
                <h4 className="font-headline-sm text-xs font-bold text-[#1c1c17]">
                  Priya S.
                </h4>
                <p className="font-label-stamp text-[10px] text-[#404947]">
                  Dept of Interaction Design
                </p>
              </div>
            </div>
          </div>

          {/* Note 3 */}
          <div className="relative bg-white rounded-3xl p-6 shadow-md transform -rotate-1 hover:rotate-0 transition-transform border border-[#ece8e0]">
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#3b445e] shadow" />
            <p className="font-body-lg text-base text-[#1c1c17] italic leading-relaxed pt-2">
              "The photo condition check log eliminated all that awkward deposit tension. You know exactly what state the gear is in."
            </p>
            <div className="flex items-center gap-3 mt-6 pt-2 border-t border-[#ece8e0]">
              <div className="w-8 h-8 rounded-full bg-[#dae2ff] text-[#3b445e] flex items-center justify-center font-bold text-xs">
                KV
              </div>
              <div>
                <h4 className="font-headline-sm text-xs font-bold text-[#1c1c17]">
                  Karthik V.
                </h4>
                <p className="font-label-stamp text-[10px] text-[#404947]">
                  Architecture Year 4
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM CALL-TO-ACTION PANEL */}
      <section className="max-w-7xl mx-auto px-6 pb-12 w-full">
        <div className="relative bg-[#094d48] text-white rounded-[32px] p-8 md:p-14 shadow-2xl overflow-hidden text-center flex flex-col items-center border-4 border-[#073c38]">
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#b2eee7 1.5px, transparent 1.5px)',
              backgroundSize: '20px 20px',
            }}
          />
          <div className="relative z-10 max-w-2xl flex flex-col items-center">
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-[#2a6560] text-[#a5e0d9] font-label-stamp text-[11px] uppercase mb-4 font-bold tracking-wider">
              Lender onboarding open
            </span>
            <h2 className="font-headline-xl text-3xl md:text-5xl text-white tracking-tight font-bold">
              Got gear sitting in a drawer? <br />
              Put it in the loop.
            </h2>
            <p className="font-body-lg text-base text-[#97d1cb] mt-3 max-w-lg leading-relaxed">
              Join 400+ campus peers sharing filmmaking kits, outdoor gear, and creative tools with instant photo-verification and covered security.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 mt-6">
              <button
                onClick={onOpenListGear}
                className="inline-flex items-center justify-center bg-[#994531] text-white font-label-btn text-base px-6 py-3.5 rounded-full shadow-[0_4px_0_0_#762b1a] hover:translate-y-0.5 hover:shadow-[0_2px_0_0_#762b1a] active:translate-y-1 active:shadow-none transition-all cursor-pointer font-bold"
              >
                List your gear in 2 mins <span className="ml-2 font-mono">→</span>
              </button>
              <button
                onClick={onOpenHowItWorks}
                className="font-label-btn text-sm text-[#b2eee7] hover:text-white underline underline-offset-4 cursor-pointer font-bold"
              >
                How lender protection works
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="w-full bg-[#f7f3eb] border-t border-[#bfc8c6] pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-[#bfc8c6]">
            {/* Col 1 */}
            <div className="md:col-span-5 flex flex-col items-start gap-4">
              <div className="flex items-center gap-2">
                <img
                  alt="GearLoop Logo"
                  className="h-7 w-auto object-contain"
                  src="https://lh3.googleusercontent.com/aida/AEtjO1Xl_zDYCfQvvkF4_399sn-3GdR1ETq9jcSYe3GJDdauNDCD6AfQM85qCJWQen7lUj66qBzvM3ElpAALIlgpi1DaLja2Z1rO6e0L2h8D5Q6Juhk61WF2Tt7CoJ5kLO_sm9PU66SMW7tv7TAoO_y_5QWUiSc5x76s-v75yXBlJuy9GEGjRFk9mAQs26C0KyEzI0ik-J5kTs_AFIiBV9eSK35Cvo_hRhxiNXdD_9J2r43FVICwnIt7mlGec3LD"
                />
                <span className="font-headline-sm text-xl text-[#094d48] font-bold">
                  GearLoop
                </span>
              </div>
              <p className="font-body-sm text-xs text-[#404947] max-w-sm leading-relaxed">
                The campus noticeboard for physical gear exchange. Every reservation is paired with verifiable pre- and post-rental condition custody stamps.
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-white rounded-xl border border-dashed border-[#bfc8c6] -rotate-1 shadow-xs">
                <span className="w-2.5 h-2.5 rounded-full bg-[#fd947b] ring-2 ring-[#994531]/20" />
                <span className="font-label-stamp text-[10px] text-[#1c1c17] uppercase font-bold">
                  Rent With Proof™ Guarantee
                </span>
              </div>
            </div>

            {/* Col 2 */}
            <div className="md:col-span-7 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="font-label-eyebrow text-xs text-[#404947] uppercase font-bold tracking-wider">
                  Noticeboard Categories
                </span>
                <span className="font-label-stamp text-xs text-[#094d48] underline font-bold">
                  Spring Semester 2025
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { name: 'Cameras' as GearCategory, count: 48 },
                  { name: 'Drones' as GearCategory, count: 19 },
                  { name: 'Audio & Mics' as GearCategory, count: 34 },
                  { name: 'Makers & Tools' as GearCategory, count: 62 },
                  { name: 'Outdoors' as GearCategory, count: 27 },
                  { name: 'Projectors' as GearCategory, count: 14 },
                ].map((cat) => (
                  <button
                    key={cat.name}
                    onClick={() => onGoToShelf(cat.name)}
                    className="p-3 bg-white border border-[#bfc8c6] rounded-xl hover:border-[#094d48] transition-all flex items-center justify-between shadow-xs text-left cursor-pointer group"
                  >
                    <span className="font-body-sm text-xs text-[#1c1c17] group-hover:text-[#094d48] font-medium">
                      {cat.name}
                    </span>
                    <span className="font-label-stamp text-[10px] text-[#404947] font-bold">
                      {cat.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-6 font-body-sm text-xs text-[#404947]">
              <button
                onClick={onOpenCustodyModal}
                className="hover:text-[#1c1c17] transition-colors cursor-pointer"
              >
                Custody Protocol
              </button>
              <button
                onClick={() => onGoToShelf()}
                className="hover:text-[#1c1c17] transition-colors cursor-pointer"
              >
                Noticeboard Rules
              </button>
              <button
                onClick={onOpenHowItWorks}
                className="hover:text-[#1c1c17] transition-colors cursor-pointer"
              >
                Security & Deposit
              </button>
            </div>
            <div className="font-label-stamp text-[10px] text-[#404947] font-bold">
              © 2025 GearLoop Co-Op. Pinned with care.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
